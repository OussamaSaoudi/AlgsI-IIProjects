import edu.princeton.cs.algs4.MinPQ;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Solver {
    private SearchNode goal;
    private boolean isSolvable;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) throw new IllegalArgumentException();


        SearchNode initialAdjacent = new SearchNode(initial.twin(), null, 0);
        MinPQ<SearchNode> adjacentPriorityQueue = new MinPQ<>(1);
        adjacentPriorityQueue.insert(initialAdjacent);


        SearchNode initialNode = new SearchNode(initial, null, 0);
        MinPQ<SearchNode> priorityQueue = new MinPQ<>(1);
        priorityQueue.insert(initialNode);

        if (initial.isGoal()) {
            goal = initialNode;
            isSolvable = true;
            return;
        } else if (initialAdjacent.board.isGoal()) {
            isSolvable = false;
        }


        SearchNode currentAdjacent = initialAdjacent;
        SearchNode currentBoard = initialNode;

        while (!currentAdjacent.board.isGoal() && !currentBoard.board.isGoal()) {

            currentAdjacent = adjacentPriorityQueue.delMin();
            currentBoard = priorityQueue.delMin();

            for (Board adjacentNeighbor : currentAdjacent.board.neighbors()) {
                SearchNode toBeInserted = new SearchNode(adjacentNeighbor, currentAdjacent, currentAdjacent.previousMoves + 1);
                if (currentAdjacent.previousSearchNode == null || !toBeInserted.board.equals(currentAdjacent.previousSearchNode.board)) {
                    adjacentPriorityQueue.insert(toBeInserted);
                }
            }


            for (Board neighbor : currentBoard.board.neighbors()) {
                SearchNode toBeInserted = new SearchNode(neighbor, currentBoard, currentBoard.previousMoves + 1);
                if (currentBoard.previousSearchNode == null || !toBeInserted.board.equals(currentBoard.previousSearchNode.board)) {

                    priorityQueue.insert(toBeInserted);
                }
            }
        }
        if (currentAdjacent.board.isGoal()) {
            isSolvable = false;
        } else {
            goal = currentBoard;
            isSolvable = true;
        }

    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return isSolvable;
    }

    // min number of moves to solve initial board
    public int moves() {
        return goal.previousMoves;
    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution() {
        if (!isSolvable) throw new NullPointerException("There is no solution");
        return goal;
    }


    private class SearchNode implements Comparable<SearchNode>, Iterable<Board> {
        private final Board board;
        private int manhattan;
        //private int hamming;
        private final SearchNode previousSearchNode;
        private final int previousMoves;


        private SearchNode(Board board, SearchNode previousNode, int previousMoves) {
            this.board = board;
            this.previousMoves = previousMoves;
            this.previousSearchNode = previousNode;
            if (board != null) {
                //  this.hamming = board.hamming();
                this.manhattan = board.manhattan();
            }
        }

        public boolean equals(Object otherObject) {
            if (otherObject == null) return false;
            if (otherObject.getClass() != this.getClass()) return false;
            SearchNode otherNode = (SearchNode) otherObject;
            if (!otherNode.board.equals(board)) return false;
            if (!otherNode.previousSearchNode.equals(previousSearchNode)) return false;
            if (otherNode.previousMoves != previousMoves) return false;
            return true;
        }

        public int hashCode() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int compareTo(SearchNode otherNode) {
            return manhattan + previousMoves - otherNode.previousMoves - otherNode.manhattan;
        }

        @Override
        public Iterator<Board> iterator() {
            return new SearchNodeIterator();
        }

        private class SearchNodeIterator implements Iterator<Board> {
            private SearchNode current = new SearchNode(board, previousSearchNode, previousMoves);

            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public Board next() {
                if (current == null) throw new NoSuchElementException();
                Board output = current.board;
                current = current.previousSearchNode;
                return output;

            }
        }
    }

    // test client (see below)
    public static void main(String[] args) {
// Use for unit testing
    }


}